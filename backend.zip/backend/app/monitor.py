import psutil
import time
import socket
import subprocess
from typing import Dict, Any, List
from datetime import datetime

class NetworkMonitor:
    def __init__(self):
        self.last_io_counters = psutil.net_io_counters()
        self.last_check_time = time.time()
        self.alert_thresholds = {
            "cpu_percent": 80.0,
            "memory_percent": 80.0,
            "network_latency": 100.0,  # ms
            "disk_percent": 90.0
        }
        self.history: List[Dict[str, Any]] = []
        self.max_history_size = 1000

    def check_alerts(self, stats: Dict[str, Any]) -> List[Dict[str, Any]]:
        alerts = []
        
        if stats['system']['cpu']['percent'] > self.alert_thresholds['cpu_percent']:
            alerts.append({
                'type': 'CPU_HIGH',
                'message': f"CPU usage is high: {stats['system']['cpu']['percent']}%",
                'severity': 'warning',
                'timestamp': datetime.now().isoformat()
            })
            
        if stats['system']['memory']['percent'] > self.alert_thresholds['memory_percent']:
            alerts.append({
                'type': 'MEMORY_HIGH',
                'message': f"Memory usage is high: {stats['system']['memory']['percent']}%",
                'severity': 'warning',
                'timestamp': datetime.now().isoformat()
            })
            
        if stats['system']['disk']['percent'] > self.alert_thresholds['disk_percent']:
            alerts.append({
                'type': 'DISK_HIGH',
                'message': f"Disk usage is high: {stats['system']['disk']['percent']}%",
                'severity': 'warning',
                'timestamp': datetime.now().isoformat()
            })
            
        return alerts

    def get_network_latency(self) -> Dict[str, float]:
        hosts = ['8.8.8.8', '1.1.1.1']  # Google DNS and Cloudflare DNS
        latencies = {}
        
        for host in hosts:
            try:
                start_time = time.time()
                socket.create_connection((host, 53), timeout=2)
                latency = (time.time() - start_time) * 1000
                latencies[host] = round(latency, 2)
            except (socket.timeout, socket.error):
                latencies[host] = -1
                
        return latencies

    def get_dns_resolution_time(self) -> float:
        domains = ['google.com', 'microsoft.com', 'amazon.com']
        total_time = 0
        count = 0
        
        for domain in domains:
            try:
                start_time = time.time()
                socket.gethostbyname(domain)
                resolution_time = (time.time() - start_time) * 1000
                total_time += resolution_time
                count += 1
            except socket.error:
                continue
                
        return round(total_time / count if count > 0 else -1, 2)

    def get_network_speeds(self) -> tuple[float, float]:
        """Calculate network speeds in KB/s"""
        current_time = time.time()
        current_io = psutil.net_io_counters()
        
        time_delta = current_time - self.last_check_time
        if time_delta == 0:
            return 0.0, 0.0

        # Calculate speeds in KB/s
        send_speed = (current_io.bytes_sent - self.last_io_counters.bytes_sent) / 1024 / time_delta
        recv_speed = (current_io.bytes_recv - self.last_io_counters.bytes_recv) / 1024 / time_delta

        # Update last values
        self.last_io_counters = current_io
        self.last_check_time = current_time

        return round(send_speed, 2), round(recv_speed, 2)

    def get_stats(self) -> Dict[str, Any]:
        try:
            # Get CPU stats with a small interval for more accurate reading
            cpu_percent = psutil.cpu_percent(interval=0.1)
            
            # Get memory stats
            memory = psutil.virtual_memory()
            
            # Get disk stats
            disk = psutil.disk_usage('/')
            
            # Get network speeds
            send_speed, recv_speed = self.get_network_speeds()
            
            # Get network metrics
            connections = psutil.net_connections()
            active_connections = len([conn for conn in connections if conn.status == 'ESTABLISHED'])
            listening_ports = len([conn for conn in connections if conn.status == 'LISTEN'])
            
            # Get network interfaces with additional details
            interfaces = []
            for name, stats in psutil.net_if_stats().items():
                interface_counters = psutil.net_if_addrs().get(name, [])
                addresses = []
                for addr in interface_counters:
                    addresses.append({
                        'address': addr.address,
                        'netmask': addr.netmask,
                        'family': str(addr.family)
                    })
                
                interfaces.append({
                    'name': name,
                    'isUp': stats.isup,
                    'speed': stats.speed,
                    'mtu': stats.mtu,
                    'addresses': addresses
                })

            # Compile stats in the exact format expected by frontend
            stats = {
                "timestamp": int(time.time()),
                "system": {
                    "cpu": {
                        "percent": cpu_percent
                    },
                    "memory": {
                        "total": memory.total,
                        "available": memory.available,
                        "percent": memory.percent
                    },
                    "disk": {
                        "total": disk.total,
                        "used": disk.used,
                        "free": disk.free,
                        "percent": disk.percent
                    }
                },
                "network": {
                    "send_speed": send_speed,
                    "recv_speed": recv_speed,
                    "latency": self.get_network_latency(),
                    "dns_resolution_time": self.get_dns_resolution_time(),
                    "errors_in": current_io.errin,
                    "errors_out": current_io.errout,
                    "drops_in": current_io.dropin,
                    "drops_out": current_io.dropout,
                    "active_connections": active_connections,
                    "listening_ports": listening_ports,
                    "interfaces": interfaces
                }
            }
            
            print(f"Generated stats: {stats}")  # Debug log
            return stats
            
        except Exception as e:
            print(f"Error getting system stats: {str(e)}")
            # Return a safe fallback structure
            return {
                "timestamp": int(time.time()),
                "system": {
                    "cpu": {"percent": 0},
                    "memory": {"total": 0, "available": 0, "percent": 0},
                    "disk": {"total": 0, "used": 0, "free": 0, "percent": 0}
                },
                "network": {
                    "send_speed": 0,
                    "recv_speed": 0,
                    "latency": 0,
                    "dns_resolution_time": 0,
                    "errors_in": 0,
                    "errors_out": 0,
                    "drops_in": 0,
                    "drops_out": 0,
                    "active_connections": 0,
                    "listening_ports": 0,
                    "interfaces": []
                }
            }

    def get_history(self, minutes: int = 5) -> List[Dict[str, Any]]:
        """Get historical data for the specified number of minutes"""
        if not self.history:
            return []
            
        cutoff_time = time.time() - (minutes * 60)
        return [
            stat for stat in self.history 
            if stat['timestamp'] > cutoff_time
        ]

    def export_data(self, format: str = 'json') -> Dict[str, Any]:
        """Export monitoring data in the specified format"""
        return {
            'current': self.get_stats(),
            'history': self.get_history(),
            'thresholds': self.alert_thresholds
        }

    def get_alert_thresholds(self):
        return self.alert_thresholds

    def update_alert_thresholds(self, thresholds: Dict[str, float]):
        self.alert_thresholds.update(thresholds)
        return self.alert_thresholds
