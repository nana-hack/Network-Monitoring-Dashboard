from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
from typing import Dict, Any
from .monitor import NetworkMonitor

app = FastAPI(title="Network Monitoring Dashboard")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize network monitor
network_monitor = NetworkMonitor()

@app.get("/")
async def read_root():
    return {"status": "Network Monitoring Dashboard API is running"}

@app.get("/stats")
async def get_stats():
    """Get current network statistics"""
    try:
        stats = network_monitor.get_stats()
        print(f"Sending stats to client: {stats}")  # Debug log
        return JSONResponse(content=stats)
    except Exception as e:
        print(f"Error in /stats endpoint: {str(e)}")  # Debug log
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/history/{minutes}")
async def get_history(minutes: int = 5):
    """Get historical network statistics"""
    try:
        return network_monitor.get_history(minutes)
    except Exception as e:
        print(f"Error in /history endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/alert-thresholds")
async def get_alert_thresholds():
    """Get current alert thresholds"""
    try:
        return network_monitor.get_alert_thresholds()
    except Exception as e:
        print(f"Error in /alert-thresholds endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/alert-thresholds")
async def update_alert_thresholds(thresholds: Dict[str, float]):
    """Update alert thresholds"""
    try:
        return network_monitor.update_alert_thresholds(thresholds)
    except Exception as e:
        print(f"Error in update_alert_thresholds endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/export")
async def export_data(format: str = "json"):
    """Export monitoring data"""
    try:
        return network_monitor.export_data(format)
    except Exception as e:
        print(f"Error in /export endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    print("New WebSocket connection request")  # Debug log
    await websocket.accept()
    print("WebSocket connection accepted")  # Debug log
    
    try:
        while True:
            stats = network_monitor.get_stats()
            print(f"Sending WebSocket stats: {stats}")  # Debug log
            await websocket.send_json(stats)
            await asyncio.sleep(1)
    except Exception as e:
        print(f"WebSocket error: {str(e)}")
    finally:
        print("WebSocket connection closed")
        await websocket.close()
